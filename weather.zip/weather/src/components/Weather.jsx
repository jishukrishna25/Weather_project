import React, { useState } from 'react'

import cloud from "./image/Clouds.png"
import rain from "./image/Rain.png"
import clear from "./image/Clear.png"
import mist from "./image/mist.png"
import err from "./image/error.png"

const Weather = () => {
    const [search, setSearch] = useState("");
    const [data, setData] = useState();
    const [error, setError] = useState();

    const API_KEY = 'cec810c2d5cb5686c90ed51beff80478'
    // const API = "https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}"

    const handleInput = (event) => {
        setSearch(event.target.value)                                                                //! input vetare jou event achi seta target kariba value ku mane input vetare jou value daba setaku se target kariba then Setsearch vetare assign karidaba then seta current state search vetare asijiba  
        console.log(event.target.value);
    }

    const myFun = async () => {
        const get = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${search}&appid=${API_KEY}&units=metric`);        //! units=metric =it convert into degree celsius .

        const jsonData = await get.json()                                                              //! Ata get variable re jou data achi taku json format ku convert karayela for user understandable .
        console.log(jsonData);
        setData(jsonData);                                                                              //! Jou JSON data asuchi get variable ru taku useState re setData ku pass karagala 



        if (search === "") {
            // alert("Enter name")
            setError("Please Enter Name")
        }
        else if (jsonData.cod == '404') {                                                              //! (cod : amaku janaye name thik achi ke nahi) jadi bhull name enter kala then 404 ase
            setError("Please Enter Valid Name !")
        } else {
            setError("")
        }
        setSearch("")
    }

    

    return (
        <>
            <div className='container'>
                <div className='inputs'>
                    <input placeholder='Enter city, Country' value={search} onChange={handleInput} />             {/* value re search dele sabu fetch hayeke gala pare input field empty hayejiba  */}
                    <button onClick={myFun}>Search</button>
                </div>
                <div>
                    {
                        error ?
                            <div className='errorPage'>
                                <p>{error}</p>
                                <img src={err} />
                            </div> : ""
                    }
                    {
                        data && data.weather ?
                            <div className='weathers'>
                                <h2 className='cityName'>{data.name}</h2>
                                <img src={data.weather[0].main == "Clouds" ? cloud : ""} />                    {/*data vetare weather weather vetare 0 index re main ta vetare asuchi clouds so cloud ra pic asiba */}
                                <img src={data.weather[0].main == "Rain" ? rain : ""} />                       {/*data vetare weather weather vetare 0 index re main ta vetare asuchi rain so rain ra pic asiba */}
                                <img src={data.weather[0].main == "Clear" ? clear : ""} />                     {/*data vetare weather weather vetare 0 index re main ta vetare asuchi clear so clear ra pic asiba */}
                                <img src={data.weather[0].main == "Mist" ? mist : ""} />                       {/*data vetare weather weather vetare 0 index re main ta vetare asuchi mist so mist ra pic asiba */}
                                <img src={data.weather[0].main == "Haze" ? cloud : ""} />                      {/*data vetare weather weather vetare 0 index re main ta vetare asuchi haze so cloud ra pic asiba */}

                                <h2 className='temprature'>{Math.trunc(data.main.temp)}°C</h2>                 {/*Math.trunc  = ata point (.)  pare jou value ase taku remve karidia */}
                                <p className='climate'>{data.weather[0].description}</p>

                            </div> : ""
                    }

                </div>
            </div>
        </>
    )
}

export default Weather